var struct_c_f_g___v_a_r___d_e_f =
[
    [ "name", "d0/d23/struct_c_f_g___v_a_r___d_e_f.html#a8f8f80d37794cde9472343e4487ba3eb", null ],
    [ "type", "d0/d23/struct_c_f_g___v_a_r___d_e_f.html#a58b828d42c859f472f45fe3ed271646c", null ],
    [ "pData", "d0/d23/struct_c_f_g___v_a_r___d_e_f.html#a6cd690a1eb65b76d4cd46f0360659aaa", null ]
];