var em__common_8h =
[
    [ "EFM32_MIN", "dc/d56/group___c_o_m_m_o_n.html#gaf681fcd13024b5e6a44cd7f330b74cc4", null ],
    [ "EFM32_MAX", "dc/d56/group___c_o_m_m_o_n.html#gab9b4265c10fac1d4b4328a916a688d3b", null ],
    [ "EFM32_PACK_START", "dc/d56/group___c_o_m_m_o_n.html#ga099d98fa4e24657df90ae06fc13a4815", null ],
    [ "EFM32_PACK_END", "dc/d56/group___c_o_m_m_o_n.html#gab2675861d42aae2af68c05f8fa1da22f", null ],
    [ "EFM32_ALIGN", "dc/d56/group___c_o_m_m_o_n.html#ga3e1e293640dd826cbd20924b763ddcc0", null ]
];