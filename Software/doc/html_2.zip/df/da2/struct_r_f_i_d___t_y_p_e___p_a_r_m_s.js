var struct_r_f_i_d___t_y_p_e___p_a_r_m_s =
[
    [ "Baudrate", "df/da2/struct_r_f_i_d___t_y_p_e___p_a_r_m_s.html#a96777c572a3392ffff8e07554ff27d65", null ],
    [ "DataBits", "df/da2/struct_r_f_i_d___t_y_p_e___p_a_r_m_s.html#a70857ba71ff684e4dc97aaf2ff53a815", null ],
    [ "Parity", "df/da2/struct_r_f_i_d___t_y_p_e___p_a_r_m_s.html#a7c8bf6f9f53a21da7eb46af641346b83", null ],
    [ "StopBits", "df/da2/struct_r_f_i_d___t_y_p_e___p_a_r_m_s.html#a3d66706d17d005e4a401b170b353a864", null ]
];