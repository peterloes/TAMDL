var struct_e_x_t_i___i_n_i_t =
[
    [ "IntBitMask", "d6/d6c/struct_e_x_t_i___i_n_i_t.html#ad122ab88fa28a1a27832d6fca317e0b5", null ],
    [ "IntFct", "d6/d6c/struct_e_x_t_i___i_n_i_t.html#a605666929313ad6585e97ae1adcc4dd6", null ]
];