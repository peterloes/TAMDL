var _d_m___power_output_8h =
[
    [ "DM_PowerStatus", "d8/dde/_d_m___power_output_8h.html#a9089e4384ccf0ce9dbb29c8c194f0ccc", null ],
    [ "DM_Calibration", "d8/dde/_d_m___power_output_8h.html#a84c23c34b86fcb825eb99a66f30256df", null ],
    [ "g_UA_Calib_mV", "d8/dde/_d_m___power_output_8h.html#add456104afd0e4dd499ff23002030725", null ],
    [ "g_UA_Calib_mA", "d8/dde/_d_m___power_output_8h.html#a959bcb67e9c757102eb6762dda63d96b", null ]
];