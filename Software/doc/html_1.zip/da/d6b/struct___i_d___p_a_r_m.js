var struct___i_d___p_a_r_m =
[
    [ "pNext", "da/d6b/struct___i_d___p_a_r_m.html#a8fa064d247e163160d28cde3aa41b4b9", null ],
    [ "ID", "da/d6b/struct___i_d___p_a_r_m.html#a195f2bb3d46f0e79918df60d52750798", null ]
];