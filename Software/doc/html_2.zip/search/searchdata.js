var indexSectionsWithContent =
{
  0: "_abcdefghiklmnopqrstuvwxy",
  1: "_abcdefiklmoprstuvw",
  2: "abcdefiklmprv",
  3: "_abcdefgiklmprstuvw",
  4: "abcdefghiklmnopqrstuvwx",
  5: "abcdeiklmpstuw",
  6: "abcdefgiklmprstuvw",
  7: "abcdefghiklmnprstuvw",
  8: "_abcdefgiklmnprstuwy",
  9: "abcdegilmprstuvw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Modules"
};

