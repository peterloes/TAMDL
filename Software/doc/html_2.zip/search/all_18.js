var searchData=
[
  ['y2k38_5fwday',['Y2K38_WDAY',['../da/d26/_alarm_clock_8h.html#a0ea2c0541544f33df7176bc8d7266168',1,'AlarmClock.h']]],
  ['y2k38_5fworkaround',['Y2K38_WORKAROUND',['../da/d26/_alarm_clock_8h.html#a088ebbc3ca47f9c1da982d583351b7a1',1,'AlarmClock.h']]]
];
