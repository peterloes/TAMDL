var struct_m_e_a_s_u_r_e___d_e_f =
[
    [ "BitBandAddr", "dd/d54/struct_m_e_a_s_u_r_e___d_e_f.html#ad22de4ec361cb9d7f6f96e32b921a776", null ],
    [ "hdlFollowUpTime", "dd/d54/struct_m_e_a_s_u_r_e___d_e_f.html#a9e8194faf13d7e17ed79db4264a7d516", null ],
    [ "FollowUpTime", "dd/d54/struct_m_e_a_s_u_r_e___d_e_f.html#ae08074eb7964a73839c88cac9beacf90", null ],
    [ "ChanU", "dd/d54/struct_m_e_a_s_u_r_e___d_e_f.html#ac42e987821fc73c276652c7302412878", null ],
    [ "U_MinDiff", "dd/d54/struct_m_e_a_s_u_r_e___d_e_f.html#a5445ffbf6a17286b70b8cc7bb7b854b6", null ],
    [ "ChanI", "dd/d54/struct_m_e_a_s_u_r_e___d_e_f.html#a9fb0f48bf8e72e9ad9167164f6f25df4", null ],
    [ "I_MinDiff", "dd/d54/struct_m_e_a_s_u_r_e___d_e_f.html#ab32bf3e339bfe57508e0c366fa13abf1", null ]
];