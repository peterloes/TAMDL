var struct_a_d_c___init_scan___type_def =
[
    [ "prsSel", "dd/d7e/struct_a_d_c___init_scan___type_def.html#a7a41217e015b147a659fdecacf2e74c8", null ],
    [ "acqTime", "dd/d7e/struct_a_d_c___init_scan___type_def.html#aa26492a8e94f1c35b1af3808e459007b", null ],
    [ "reference", "dd/d7e/struct_a_d_c___init_scan___type_def.html#add502b6cd8083f28f70e2793ce7c33e8", null ],
    [ "resolution", "dd/d7e/struct_a_d_c___init_scan___type_def.html#a1e407416a9c7a57da01413115a32c0f7", null ],
    [ "input", "dd/d7e/struct_a_d_c___init_scan___type_def.html#a237ac13643964d05d26f13a42e1543b3", null ],
    [ "diff", "dd/d7e/struct_a_d_c___init_scan___type_def.html#a73c8af0fb78a0c12a7b9eb6f0f397f4f", null ],
    [ "prsEnable", "dd/d7e/struct_a_d_c___init_scan___type_def.html#a78606b3fad672fa22c1f11625fdc25ec", null ],
    [ "leftAdjust", "dd/d7e/struct_a_d_c___init_scan___type_def.html#a6acfde7148d88a62f39fcb5660dd2678", null ],
    [ "rep", "dd/d7e/struct_a_d_c___init_scan___type_def.html#ad95946ad100922534b1a63d4a6ebe897", null ]
];