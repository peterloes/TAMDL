var struct_a_d_c___init___type_def =
[
    [ "ovsRateSel", "da/db8/struct_a_d_c___init___type_def.html#ae389a7355302182f5fde2bec22ee74df", null ],
    [ "lpfMode", "da/db8/struct_a_d_c___init___type_def.html#ad2d472ec9fc001bdd56a4f17798b6886", null ],
    [ "warmUpMode", "da/db8/struct_a_d_c___init___type_def.html#a1e1b138d01ac6d7b311c343d319dda2c", null ],
    [ "timebase", "da/db8/struct_a_d_c___init___type_def.html#a2e2753c2dee3e558e653c99e687282f0", null ],
    [ "prescale", "da/db8/struct_a_d_c___init___type_def.html#ad4f9eb028b4dee0645920af8f0d86df9", null ],
    [ "tailgate", "da/db8/struct_a_d_c___init___type_def.html#af8b1963210351bce0efe576cbdb0e4b8", null ]
];