var _display_menu_8h =
[
    [ "_DM_", "d6/d97/struct___d_m__.html", "d6/d97/struct___d_m__" ],
    [ "LCD_POWER_OFF_TIMEOUT", "d1/d2a/_display_menu_8h.html#ae3b5deb362193c10443655c4654387ec", null ],
    [ "MENU_FCT", "d1/d2a/_display_menu_8h.html#a4d2b816e4cd44711cb652296a90a9e8b", null ],
    [ "DISP_FCT", "d1/d2a/_display_menu_8h.html#a74e1e62c2169398b9535517a77f77bfe", null ],
    [ "DISP_MOD", "d1/d2a/_display_menu_8h.html#a1714a7d350dd0e8bc749cf4e85b29d22", null ],
    [ "SIMPLE_MENU", "d1/d2a/_display_menu_8h.html#ae7e26bc838d0d15980bbe41c1f383e26", null ],
    [ "DISP_NEXT_FCT", "d1/d2a/_display_menu_8h.html#a36e0f98d6e4667f405624c2db05c7394", null ],
    [ "UPD_ID", "d1/d2a/_display_menu_8h.html#a244d76167cb0b6e17e48cc5ad13b99a4", [
      [ "UPD_ALL", "d1/d2a/_display_menu_8h.html#a244d76167cb0b6e17e48cc5ad13b99a4abb02edd62c720c325d7e42f7d65bb23e", null ],
      [ "UPD_CONFIGURATION", "d1/d2a/_display_menu_8h.html#a244d76167cb0b6e17e48cc5ad13b99a4a64e61dff1ee4d8f350c35d56d8e76c54", null ],
      [ "UPD_SYSCLOCK", "d1/d2a/_display_menu_8h.html#a244d76167cb0b6e17e48cc5ad13b99a4af0a9a3fe43c2c7c1b54172212bf049af", null ],
      [ "UPD_TRANSPONDER", "d1/d2a/_display_menu_8h.html#a244d76167cb0b6e17e48cc5ad13b99a4a81fbc1256f5929a13b47b1282af59326", null ],
      [ "UPD_POWERSTATUS", "d1/d2a/_display_menu_8h.html#a244d76167cb0b6e17e48cc5ad13b99a4adeb160f10590502df5052ca2de482967", null ],
      [ "END_UPD_ID", "d1/d2a/_display_menu_8h.html#a244d76167cb0b6e17e48cc5ad13b99a4a9ed8d55c4a7c0b4c3c8abd46bc7b3ea4", null ]
    ] ],
    [ "MenuInit", "d1/d2a/_display_menu_8h.html#a3ba101e386b2e5e1f0da7b14fb1460ac", null ],
    [ "MenuKeyHandler", "d1/d2a/_display_menu_8h.html#a6ae812d11c54da5e2315e2b58dd06f8f", null ],
    [ "IsHomeScreen", "d1/d2a/_display_menu_8h.html#ab7b9bad3e50822e3dedd693b600b940d", null ],
    [ "DisplayTimerRestart", "d1/d2a/_display_menu_8h.html#a741e30ce758ff888cedf78693d084291", null ],
    [ "DisplayTimerCancel", "d1/d2a/_display_menu_8h.html#a65e73486b733fc3f717d451d282ff889", null ],
    [ "DisplayUpdateCheck", "d1/d2a/_display_menu_8h.html#adacf8d672bed19c6774e2aac115dfecf", null ],
    [ "DisplayUpdate", "d1/d2a/_display_menu_8h.html#a419cdb72b6308700ecaf4b96535cd715", null ],
    [ "DisplayUpdEnable", "d1/d2a/_display_menu_8h.html#a56c18ebb5d2d3bdcdf0ae9868bad5f5d", null ],
    [ "DispPrintf", "d1/d2a/_display_menu_8h.html#a20f141dd8e2ad6a90b71ebf91c45aa10", null ],
    [ "DisplayText", "d1/d2a/_display_menu_8h.html#a53058f21ccdbd5fb5932d361cdf4c873", null ],
    [ "DisplayNext", "d1/d2a/_display_menu_8h.html#ab2b1d48021532676134a7f602a63b4b0", null ],
    [ "DisplayUpdateClock", "d1/d2a/_display_menu_8h.html#a346eb5685f261ebddbc5a04bc37232c3", null ],
    [ "MenuDistributor", "d1/d2a/_display_menu_8h.html#a0110507aef5cd4545c00f825431cbd8c", null ]
];