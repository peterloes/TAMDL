var _d_m___power_8h =
[
    [ "MenuTimeTransp", "dc/d47/_d_m___power_8h.html#a3da9f3ba102a3c4d33d52984b7fdced2", null ],
    [ "DM_TimeTransp", "dc/d47/_d_m___power_8h.html#a6bb8c0fef3cfa68a7636fc210f5a13a3", null ]
];