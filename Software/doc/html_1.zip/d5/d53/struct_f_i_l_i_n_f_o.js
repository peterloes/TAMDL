var struct_f_i_l_i_n_f_o =
[
    [ "fsize", "d5/d53/struct_f_i_l_i_n_f_o.html#af70a0afd16367837984d6205cbfca308", null ],
    [ "fdate", "d5/d53/struct_f_i_l_i_n_f_o.html#af49edeb97b10af8854cc15a05947a7d4", null ],
    [ "ftime", "d5/d53/struct_f_i_l_i_n_f_o.html#adb685b4c58c087d1cd790afb710001cb", null ],
    [ "fattrib", "d5/d53/struct_f_i_l_i_n_f_o.html#a8d28e8b20d001f36bf6099d312384fbd", null ],
    [ "fname", "d5/d53/struct_f_i_l_i_n_f_o.html#a7c33845207b44ca3b394052ad6724e72", null ]
];