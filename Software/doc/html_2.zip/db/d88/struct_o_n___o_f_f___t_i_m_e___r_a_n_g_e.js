var struct_o_n___o_f_f___t_i_m_e___r_a_n_g_e =
[
    [ "PowerOutName", "db/d88/struct_o_n___o_f_f___t_i_m_e___r_a_n_g_e.html#a547a8a6e1fade1e19749673d8a7bd50f", null ],
    [ "OnTimeBase", "db/d88/struct_o_n___o_f_f___t_i_m_e___r_a_n_g_e.html#a036b7c864c9a175192c208a443b1052e", null ],
    [ "OnTimeCount", "db/d88/struct_o_n___o_f_f___t_i_m_e___r_a_n_g_e.html#ac4e151f93af1cb6173fde0b73eac6618", null ],
    [ "OffTimeBase", "db/d88/struct_o_n___o_f_f___t_i_m_e___r_a_n_g_e.html#aa4c784c7d9d70a09b241b77248c044c4", null ],
    [ "OffTimeCount", "db/d88/struct_o_n___o_f_f___t_i_m_e___r_a_n_g_e.html#af4426e78fab0c1dd7ab713b49b2e3f67", null ]
];