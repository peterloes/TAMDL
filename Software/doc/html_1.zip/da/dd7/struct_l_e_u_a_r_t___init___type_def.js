var struct_l_e_u_a_r_t___init___type_def =
[
    [ "enable", "da/dd7/struct_l_e_u_a_r_t___init___type_def.html#a98e5c02553709fae73fcce68e351cf73", null ],
    [ "refFreq", "da/dd7/struct_l_e_u_a_r_t___init___type_def.html#a3b647a722e160769390ac1967b22b318", null ],
    [ "baudrate", "da/dd7/struct_l_e_u_a_r_t___init___type_def.html#ac4f06ea26ed6bd7ae83b92d64ac10b78", null ],
    [ "databits", "da/dd7/struct_l_e_u_a_r_t___init___type_def.html#aefdd5595ffda9f304d633b9028a0c56f", null ],
    [ "parity", "da/dd7/struct_l_e_u_a_r_t___init___type_def.html#abcd3df8a64e16cdcd6941686948be516", null ],
    [ "stopbits", "da/dd7/struct_l_e_u_a_r_t___init___type_def.html#a376381d7f3f691f29e7aba7b59994cf5", null ]
];