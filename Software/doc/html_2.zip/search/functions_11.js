var searchData=
[
  ['validate',['validate',['../db/d89/ff_8c.html#a42019c7a77bd17ae6732775fd5b0bf9b',1,'ff.c']]],
  ['vcmp_5fdisable',['VCMP_Disable',['../d4/d35/group___v_c_m_p.html#ga4d05b8a07f535aea84df53ffcc0904da',1,'em_vcmp.h']]],
  ['vcmp_5fenable',['VCMP_Enable',['../d4/d35/group___v_c_m_p.html#gacd1e72c9db56316c049efb14e3aa2fc2',1,'em_vcmp.h']]],
  ['vcmp_5finit',['VCMP_Init',['../d4/d35/group___v_c_m_p.html#ga52aa53df539c0d68c1e2e0f5b4b40041',1,'em_vcmp.h']]],
  ['vcmp_5fintclear',['VCMP_IntClear',['../d4/d35/group___v_c_m_p.html#ga90c047e9c776cad27065458add1486fd',1,'em_vcmp.h']]],
  ['vcmp_5fintdisable',['VCMP_IntDisable',['../d4/d35/group___v_c_m_p.html#ga67704d1b4bfa3b74f0a5991efc64ef6d',1,'em_vcmp.h']]],
  ['vcmp_5fintenable',['VCMP_IntEnable',['../d4/d35/group___v_c_m_p.html#gaf52eef153dec125bcc731ad0d31e3f11',1,'em_vcmp.h']]],
  ['vcmp_5fintget',['VCMP_IntGet',['../d4/d35/group___v_c_m_p.html#ga2c95d208b80bffc906fef5c3bcdeacc8',1,'em_vcmp.h']]],
  ['vcmp_5fintgetenabled',['VCMP_IntGetEnabled',['../d4/d35/group___v_c_m_p.html#gaffed33ef4b644cd0f52bf99613012473',1,'em_vcmp.h']]],
  ['vcmp_5fintset',['VCMP_IntSet',['../d4/d35/group___v_c_m_p.html#ga4f19b07662931f087951ba5ff5af1189',1,'em_vcmp.h']]],
  ['vcmp_5flowpowerrefset',['VCMP_LowPowerRefSet',['../d4/d35/group___v_c_m_p.html#gab87bb21a4afe57c7721d424e2f8e99c5',1,'em_vcmp.h']]],
  ['vcmp_5fready',['VCMP_Ready',['../d4/d35/group___v_c_m_p.html#ga8ded00997c333fd43ebb3c5ad888bac7',1,'em_vcmp.h']]],
  ['vcmp_5ftriggerset',['VCMP_TriggerSet',['../d4/d35/group___v_c_m_p.html#ga185203f0a0c2e0343cca51d82b2b21ef',1,'em_vcmp.h']]],
  ['vcmp_5fvddhigher',['VCMP_VDDHigher',['../d4/d35/group___v_c_m_p.html#ga9ec536ab9b943fcf5c1ec34feb951f13',1,'em_vcmp.h']]],
  ['vcmp_5fvddlower',['VCMP_VDDLower',['../d4/d35/group___v_c_m_p.html#gac052041a40fe31b2d6b6536628674b24',1,'em_vcmp.h']]],
  ['vcmp_5fvoltagetolevel',['VCMP_VoltageToLevel',['../d4/d35/group___v_c_m_p.html#ga90bc9473c20571d6a6938b3afbdd26c7',1,'em_vcmp.h']]],
  ['voltage_5fto_5fadc_5fvalue',['Voltage_To_ADC_Value',['../d2/d81/_control_8c.html#abdffc418b462c0b31db63245faa768f5',1,'Voltage_To_ADC_Value(PWR_OUT output, uint32_t value_mV):&#160;Control.c'],['../dc/df5/_control_8h.html#abdffc418b462c0b31db63245faa768f5',1,'Voltage_To_ADC_Value(PWR_OUT output, uint32_t value_mV):&#160;Control.c']]]
];
