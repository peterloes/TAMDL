var eeprom__emulation_8c =
[
    [ "EE_validateIfErased", "d2/da1/eeprom__emulation_8c.html#a99b348d0f6a40532d7320d7bddb5dc09", null ],
    [ "EE_WriteToPage", "d2/da1/eeprom__emulation_8c.html#af59a78a6e15d3d713e8f485bec942564", null ],
    [ "EE_Format", "d2/da1/eeprom__emulation_8c.html#ae4b4ed0b76067f924f4c552452dcb1cb", null ],
    [ "EE_TransferPage", "d2/da1/eeprom__emulation_8c.html#a03a4e58f1daa84a9ee9ecce11b8d2df8", null ],
    [ "EE_Init", "d2/da1/eeprom__emulation_8c.html#a1a14d6dec9df11059c031f462b0df127", null ],
    [ "EE_Read", "d2/da1/eeprom__emulation_8c.html#a082ff37cc62f1d381cc42a01caeecec7", null ],
    [ "EE_Write", "d2/da1/eeprom__emulation_8c.html#a73ea2ccea258e8d71922a3c98c4eb462", null ],
    [ "EE_DeleteVariable", "d2/da1/eeprom__emulation_8c.html#a9be0ec76d40c57a34fd6058fc37948cd", null ],
    [ "EE_DeclareVariable", "d2/da1/eeprom__emulation_8c.html#a9783c147f3495ba96b8fb89d99ced0b4", null ],
    [ "EE_GetEraseCount", "d2/da1/eeprom__emulation_8c.html#a11852f9fdcfeca289df3928c5b9ddd1c", null ],
    [ "activePageNumber", "d2/da1/eeprom__emulation_8c.html#a24f45bc404b40a8822f443022ad15fb1", null ],
    [ "receivingPageNumber", "d2/da1/eeprom__emulation_8c.html#ae46c162e0d66b4f59bb67a64252117c0", null ],
    [ "initialized", "d2/da1/eeprom__emulation_8c.html#aedeffc7d23da25d52b9a50045189fe2b", null ],
    [ "pages", "d2/da1/eeprom__emulation_8c.html#a3c8a0c6c0cd8eb1f9acf8c0ac2c6d200", null ],
    [ "numberOfVariablesDeclared", "d2/da1/eeprom__emulation_8c.html#a2137c79c2ddedac72bc2ed3a97b423d5", null ],
    [ "numberOfActiveVariables", "d2/da1/eeprom__emulation_8c.html#a5283acf91d821a2835a301eb67057bf8", null ],
    [ "numberOfPagesAllocated", "d2/da1/eeprom__emulation_8c.html#aeeda2038a5f1d7dafa0a60738e62e2d3", null ]
];