var searchData=
[
  ['short',['SHORT',['../d6/d3d/integer_8h.html#a78509a33db204fd62f2f684019150cf8',1,'integer.h']]],
  ['simple_5fmenu',['SIMPLE_MENU',['../d1/d2a/_display_menu_8h.html#ae7e26bc838d0d15980bbe41c1f383e26',1,'DisplayMenu.h']]]
];
