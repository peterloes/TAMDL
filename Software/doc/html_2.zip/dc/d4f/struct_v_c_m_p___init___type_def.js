var struct_v_c_m_p___init___type_def =
[
    [ "halfBias", "dc/d4f/struct_v_c_m_p___init___type_def.html#acbb92db3a14fd71e0eb0d0fd9d9df89b", null ],
    [ "biasProg", "dc/d4f/struct_v_c_m_p___init___type_def.html#adbd3aea64f5e709d49fe2d3aa851c833", null ],
    [ "irqFalling", "dc/d4f/struct_v_c_m_p___init___type_def.html#a2ab8cde23c7a4da3b355ce74331c6262", null ],
    [ "irqRising", "dc/d4f/struct_v_c_m_p___init___type_def.html#a7c8cde290b136a861c3b411aa02f6c98", null ],
    [ "warmup", "dc/d4f/struct_v_c_m_p___init___type_def.html#a15a0ec7e11b0788caa3e985e8f0881da", null ],
    [ "hyst", "dc/d4f/struct_v_c_m_p___init___type_def.html#a4fee887b8fb28edc0349c68479ab46cc", null ],
    [ "inactive", "dc/d4f/struct_v_c_m_p___init___type_def.html#ab9f8cb1474be2bd57a5704f04887609d", null ],
    [ "lowPowerRef", "dc/d4f/struct_v_c_m_p___init___type_def.html#aef0753f3615cc32db3490c129df6fd2d", null ],
    [ "triggerLevel", "dc/d4f/struct_v_c_m_p___init___type_def.html#a68cad0dddfb1adccebad6f166585337b", null ],
    [ "enable", "dc/d4f/struct_v_c_m_p___init___type_def.html#ac842b6c1dcb3b1f11b611620199dc55c", null ]
];