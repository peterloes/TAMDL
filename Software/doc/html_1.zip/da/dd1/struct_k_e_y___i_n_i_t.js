var struct_k_e_y___i_n_i_t =
[
    [ "AR_Threshold", "da/dd1/struct_k_e_y___i_n_i_t.html#af2f883b466f92382accd90073bc4f3d2", null ],
    [ "AR_Rate", "da/dd1/struct_k_e_y___i_n_i_t.html#ac142ae403cffda71c47b2259728df2c9", null ],
    [ "KeyFct", "da/dd1/struct_k_e_y___i_n_i_t.html#af0b7b51cc55cf2c6f1873e5ece5ae716", null ]
];