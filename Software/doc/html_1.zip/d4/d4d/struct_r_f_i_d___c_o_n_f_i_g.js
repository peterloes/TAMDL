var struct_r_f_i_d___c_o_n_f_i_g =
[
    [ "RFID_Type", "d4/d4d/struct_r_f_i_d___c_o_n_f_i_g.html#a10816baf16f27baf11d2248b2a9f2f5e", null ],
    [ "RFID_PwrOut", "d4/d4d/struct_r_f_i_d___c_o_n_f_i_g.html#a3f6cfc764d6f6df95b55ca26cda80a48", null ]
];