var searchData=
[
  ['key_5finit',['KEY_INIT',['../da/dd1/struct_k_e_y___i_n_i_t.html',1,'']]]
];
