var struct___d_m__ =
[
    [ "MenuFct", "d6/d97/struct___d_m__.html#af0886aa3ac45ef59b2fd10cb3e35d511", null ],
    [ "Arg", "d6/d97/struct___d_m__.html#a5d2f41af905e18cddfc360f065073366", null ],
    [ "DispFct", "d6/d97/struct___d_m__.html#a8dd18814354e7c3d03066e0d366847c7", null ],
    [ "pNextMenu", "d6/d97/struct___d_m__.html#aa62443cd3e70fbf699fa04ed14380f37", null ]
];