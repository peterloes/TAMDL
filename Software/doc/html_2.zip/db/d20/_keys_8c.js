var _keys_8c =
[
    [ "KEY_STATE", "db/d20/_keys_8c.html#a1cc30adc1a93db98bc0e2537978a3ed7", [
      [ "KEY_IDLE", "db/d20/_keys_8c.html#a1cc30adc1a93db98bc0e2537978a3ed7a692901b9e40247863d81b06b01a5327f", null ],
      [ "KEY_UP", "db/d20/_keys_8c.html#a1cc30adc1a93db98bc0e2537978a3ed7a0848a442d907968b211b97bc2bd88acd", null ],
      [ "KEY_DOWN", "db/d20/_keys_8c.html#a1cc30adc1a93db98bc0e2537978a3ed7aa9cdac7967bf7d88fdb761138a2a3416", null ],
      [ "KEY_RIGHT", "db/d20/_keys_8c.html#a1cc30adc1a93db98bc0e2537978a3ed7a6504370d9c6391e1a9da6a1a529b089d", null ],
      [ "KEY_LEFT", "db/d20/_keys_8c.html#a1cc30adc1a93db98bc0e2537978a3ed7a612120b69c7dfd46086db7aaebdbcf65", null ],
      [ "KEY_SET", "db/d20/_keys_8c.html#a1cc30adc1a93db98bc0e2537978a3ed7a368a9f9c881efcaf697bdbd9d6e5cd8d", null ],
      [ "KEY_CNT", "db/d20/_keys_8c.html#a1cc30adc1a93db98bc0e2537978a3ed7ad844e3d999f31a49106e862970bfd5a8", null ]
    ] ],
    [ "KeyTimerFct", "db/d20/_keys_8c.html#a712afd0aadf82290e704d7f29bfe03fa", null ],
    [ "KeyInit", "db/d20/_keys_8c.html#aead7281356b65fb68529b3baaa263d1b", null ],
    [ "KeyHandler", "db/d20/_keys_8c.html#aa2e9146eb68121ec8c921491eaace740", null ],
    [ "l_pKeyInit", "db/d20/_keys_8c.html#a86a5fe4ac83ab0b9d92942c217f80b98", null ],
    [ "l_KeyState", "db/d20/_keys_8c.html#ae1398fb77cd1f3e6b64beda2dda7db03", null ],
    [ "l_KeyCode", "db/d20/_keys_8c.html#a9e1a4915b87c3a7e4b6aa77da040a0a3", null ]
];