var struct_e_e___variable___type_def =
[
    [ "virtualAddress", "d6/ddd/struct_e_e___variable___type_def.html#a6cf8e56eef5d0afcbd746136ea67d1ad", null ]
];