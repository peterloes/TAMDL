var searchData=
[
  ['bat_5finfo',['BAT_INFO',['../da/d63/struct_b_a_t___i_n_f_o.html',1,'']]]
];
