var struct_p_w_r___o_u_t___d_e_f =
[
    [ "BitBandAddr", "d2/d9a/struct_p_w_r___o_u_t___d_e_f.html#ad22de4ec361cb9d7f6f96e32b921a776", null ],
    [ "Measure", "d2/d9a/struct_p_w_r___o_u_t___d_e_f.html#a6ee21b0151ed4dd3f7c220d0875abb9a", null ]
];