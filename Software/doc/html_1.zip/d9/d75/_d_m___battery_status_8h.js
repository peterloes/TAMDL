var _d_m___battery_status_8h =
[
    [ "DM_BatteryStatus", "d9/d75/_d_m___battery_status_8h.html#a84807accf6f2494f23c74bd4f5242547", null ]
];